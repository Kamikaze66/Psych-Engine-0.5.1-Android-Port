function onCreatePost()

    for i=0,3 do
        setPropertyFromGroup('opponentStrums',i,'texture', 'notglow')
    end

  
end